package org.apache.axis.ime;

/**
 * The MessageExchange interface always assumes a One-way send or 
 * Send/Receive pattern.  Receive, Status and Fault Listeners are
 * only registered if there is first an initial send operation.
 * This interface can be used to listen to a channel in receive-only
 * cases.
 * 
 * @author James M Snell (jasnell@us.ibm.com)
 */
public interface MessageReceiver {

  public void setMessageExchangeReceiveListener(
    MessageExchangeReceiveListener listener);
    
  public void setMessageExchangeStatusListener(
    MessageExchangeStatusListener listener);
    
  public void setMessageExchangeFaultListener(
    MessageExchangeFaultListener listener);
    
  public void listen();
  
  public void cancel();
  
  public void cancel(boolean force);

}
