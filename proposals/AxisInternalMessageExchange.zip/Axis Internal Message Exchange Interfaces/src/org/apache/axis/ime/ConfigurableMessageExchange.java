package org.apache.axis.ime;

import java.util.Map;

/**
 * Extends the basic MessageExchange interface to allow
 * applications to configure the MessageExchange
 * 
 * Feature == things like Session support, 
 * Reliable Delivery support, etc
 * 
 * @author James M Snell (jasnell@us.ibm.com)
 */
public interface ConfigurableMessageExchange 
  extends MessageExchange {

  public void enableFeature(String featureId);
  
  public void disableFeature(String featureId);
  
  public boolean isFeatureEnabled(String featureId);
  
  public void setProperty(
    String propertyId, 
    Object propertyValue);  
  
  public Object getProperty(
    String propertyId);
    
  public Object getProperty(
    String propertyId,
    Object defaultValue);
    
  public Map getProperties();
  
  public void clearProperties();
  
}
