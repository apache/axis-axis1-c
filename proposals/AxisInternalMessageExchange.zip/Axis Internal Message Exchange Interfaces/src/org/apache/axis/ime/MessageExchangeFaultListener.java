package org.apache.axis.ime;

/**
 * @author James M Snell (jasnell@us.ibm.com)
 */
public interface MessageExchangeFaultListener {

  public void onFault(
    MessageExchangeCorrelator correlator,
    Throwable exception);

}
