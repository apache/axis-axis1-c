package org.apache.axis.ime;

/**
 * Used for correlating outbound/inbound messages
 * 
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class MessageExchangeCorrelator {

  private String identifier;

  private MessageExchangeCorrelator() {}
  
  public MessageExchangeCorrelator(
    String identifier) {
      this.identifier = identifier;
  }

  public String getIdentifier() {
    return this.identifier;
  }

}
