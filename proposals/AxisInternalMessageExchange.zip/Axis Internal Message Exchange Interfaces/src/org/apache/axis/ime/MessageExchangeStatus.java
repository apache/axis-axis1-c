package org.apache.axis.ime;

/**
 * Used to indicate a MessageExchangeStatus event
 * 
 * @author James M Snell (jasnell@us.ibm.com)
 */
public interface MessageExchangeStatus {}
