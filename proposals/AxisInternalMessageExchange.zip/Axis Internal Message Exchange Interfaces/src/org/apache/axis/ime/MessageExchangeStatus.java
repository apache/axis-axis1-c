package org.apache.axis.ime;

/**
 * Used to indicate a custom MessageExchange event
 * 
 * @author James M Snell (jasnell@us.ibm.com)
 */
public interface MessageExchangeStatus {}
