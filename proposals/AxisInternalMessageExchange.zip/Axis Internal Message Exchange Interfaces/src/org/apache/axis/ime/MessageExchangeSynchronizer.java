package org.apache.axis.ime;

import org.apache.axis.AxisFault;
import org.apache.axis.MessageContext;
import org.apache.axis.ime.MessageExchange;
import org.apache.axis.ime.MessageExchangeCorrelator;
import org.apache.axis.ime.MessageExchangeReceiveListener;
import org.apache.axis.ime.MessageExchangeFaultListener;

/**
 * Used to synchronize send and receives on the MessageExchange
 * 
 * @author James M Snell (jasnell@us.ibm.com)
 */
public interface MessageExchangeSynchronizer {

  public MessageExchange getMessageExchange();
  
  public MessageContext sendAndReceive(
    MessageContext context)
      throws AxisFault;

  public MessageContext sendAndReceive(
    MessageContext context,
    long timeout)
      throws AxisFault;

}


