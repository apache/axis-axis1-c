package org.apache.axis.ime;

import java.io.Serializable;
import org.apache.axis.MessageContext;

/**
 * Note: the only challenge with making this class serializable
 * is that org.apache.axis.MessageContext is currently NOT
 * serializable.  MessageContext needs to change in order to 
 * take advantage of persistent Channels and CorrelatorServices
 * 
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class MessageExchangeContext
  implements Serializable {

  private MessageExchangeCorrelator correlator;
  private MessageExchangeStatusListener statusListener;
  private MessageExchangeReceiveListener receiveListener;
  private MessageExchangeFaultListener faultListener;
  private MessageContext context;

  private MessageExchangeContext() {}
  
  public MessageExchangeContext(
    MessageExchangeCorrelator correlator,
    MessageExchangeStatusListener statusListener,
    MessageExchangeReceiveListener receiveListener,
    MessageExchangeFaultListener faultListener,
    MessageContext context) {
      this.correlator = correlator;
      this.statusListener = statusListener;
      this.receiveListener = receiveListener;
      this.faultListener = faultListener;
      this.context = context;
  }

  public MessageExchangeCorrelator getMessageExchangeCorrelator() {
    return this.correlator;
  }
  
  public MessageExchangeReceiveListener getMessageExchangeReceiveListener() {
    return this.receiveListener;
  }
  
  public MessageExchangeStatusListener getMessageExchangeStatusListener() {
    return this.statusListener;
  }

  public MessageExchangeFaultListener getMessageExchangeFaultListener() {
    return this.faultListener;
  }
  
  public MessageContext getMessageContext() {
    return this.context;
  }

}
