package org.apache.axis.ime;

import org.apache.axis.MessageContext;

/**
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class MessageExchangeContext {

  private MessageExchangeCorrelator correlator;
  private MessageExchangeStatusListener statusListener;
  private MessageExchangeReceiveListener receiveListener;
  private MessageExchangeFaultListener faultListener;
  private MessageContext context;

  private MessageExchangeContext() {}
  
  public MessageExchangeContext(
    MessageExchangeCorrelator correlator,
    MessageExchangeStatusListener statusListener,
    MessageExchangeReceiveListener receiveListener,
    MessageExchangeFaultListener faultListener,
    MessageContext context) {
      this.correlator = correlator;
      this.statusListener = statusListener;
      this.receiveListener = receiveListener;
      this.faultListener = faultListener;
      this.context = context;
  }

  public MessageExchangeCorrelator getMessageExchangeCorrelator() {
    return this.correlator;
  }
  
  public MessageExchangeReceiveListener getMessageExchangeReceiveListener() {
    return this.receiveListener;
  }
  
  public MessageExchangeStatusListener getMessageExchangeStatusListener() {
    return this.statusListener;
  }

  public MessageExchangeFaultListener getMessageExchangeFaultListener() {
    return this.faultListener;
  }
  
  public MessageContext getMessageContext() {
    return this.context;
  }

}
