package org.apache.axis.ime;

import org.apache.axis.MessageContext;

/**
 * @author James M Snell (jasnell@us.ibm.com)
 */
public interface MessageExchangeReceiveListener {

  public void onReceive(
    MessageExchangeCorrelator correlator,
    MessageContext context);

}
