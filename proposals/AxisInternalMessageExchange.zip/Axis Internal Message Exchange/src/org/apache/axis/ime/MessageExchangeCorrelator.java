package org.apache.axis.ime;

/**
 * Used for correlating outbound/inbound messages
 * 
 * @author James M Snell (jasnell@us.ibm.com)
 */
public interface MessageExchangeCorrelator {

  public String getIdentifier();

}
