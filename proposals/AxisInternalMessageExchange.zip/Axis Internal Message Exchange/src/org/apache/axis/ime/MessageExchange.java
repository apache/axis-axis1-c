package org.apache.axis.ime;

import org.apache.axis.AxisFault;
import org.apache.axis.MessageContext;

/**
 * Represents the boundary interface through which messages
 * are exchanged.  This interface supports both push and pull
 * models for receiving inbound messages.
 * 
 * @author James M Snell (jasnell@us.ibm.com)
 */
public interface MessageExchange {

  /**
   * Send an outbound message.  (Impl's of this method
   * need to create a new MessageExchangeCorrelator and 
   * put it into the MessageContext. The MessageContext
   * needs a property or method for setting/requesting
   * the MessageExchangeCorrelator)
   */
  public void send(
    MessageContext context)
      throws AxisFault;

  /**
   * Receive an inbound message (pull model)
   */  
  public MessageContext receive()
    throws AxisFault;
  
  /**
   * Receive an inbound message with timeout (pull model)
   */
  public MessageContext receive(
    long timeout)
      throws AxisFault;

  /**
   * Receive an inbound message with correlator (pull model)
   */
  public MessageContext receive(
    MessageExchangeCorrelator correlator)
      throws AxisFault;

  /**
   * Request the current disposition of the MessageExchange
   */
  public MessageExchangeStatus getMessageExchangeStatus()
    throws AxisFault;

  /**
   * Request the current disposition of the MessageExchange
   * given a specific MessageExchangeCorrelator
   */
  public MessageExchangeStatus getMessageExchangeStatus(
    MessageExchangeCorrelator correlator)
      throws AxisFault;

  /**
   * Allows applications to listen for changes to
   * the current disposition of the MessageExchange operation
   * (push model)
   */
  public void setMessageExchangeStatusListener(
    MessageExchangeStatusListener listener)
      throws AxisFault;
    
  /**
   * Allows applications to listen for inbound messages
   * (push model)
   */
  public void setMessageExchangeReceiveListener(
    MessageExchangeReceiveListener listener)
      throws AxisFault;
  
}
