package org.apache.axis.ime;

/**
 * Indicates the current disposition of the MessageExchange 
 * 
 * @author James M Snell (jasnell@us.ibm.com)
 */
public abstract class MessageExchangeStatus {

  private MessageExchangeCorrelator correlator;

  /**
   * Used to correlate the MessageExchangeStatus to a 
   * specific MessageContext
   */
  public MessageExchangeCorrelator getMessageExchangeCorrelator() {
    return this.correlator;
  }

  /**
   * Used to correlate the MessageExchangeStatus to a 
   * specific MessageContext
   */
  public void setMessageExchangeCorrelator(
    MessageExchangeCorrelator correlator) {
      this.correlator = correlator;
  }


  /**
   * Indicates that a message exchange exception
   */
  public abstract static class MessageExchangeExceptionStatus 
    extends MessageExchangeStatus {
      
      private Exception exception;
      
      public Exception getException() {
        return this.exception;
      }
      
      public void setException(Exception e) {
        this.exception = e;
      }      
  }

  ////// Message Exchange Event Types //////

  /**
   * Indicates that the message was sent, but delivery
   * status could not be determined
   */
  public static final class MessageSent 
    extends MessageExchangeStatus {}

  /**
   * Indicates that a message has been received
   */
  public static final class MessageReceived 
    extends MessageExchangeStatus {}
  
  /**
   * Indicates that a failure occurred while sending the message
   */
  public static final class MessageSendException
    extends MessageExchangeExceptionStatus {}
    
  /**
   * Indicates that a failure occurred while receiving a message
   */
  public static final class MessageReceivedException
    extends MessageExchangeExceptionStatus {}

}
