package org.apache.axis.ime.internal.test;

import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.ime.MessageExchange;
import org.apache.axis.ime.MessageExchangeFaultListener;
import org.apache.axis.ime.MessageExchangeStatus;
import org.apache.axis.ime.MessageExchangeStatusListener;
import org.apache.axis.ime.MessageExchangeReceiveListener;
import org.apache.axis.ime.MessageExchangeCorrelator;
import org.apache.axis.ime.internal.MessageChannel;
import org.apache.axis.ime.internal.MessageExchangeContext;
import org.apache.axis.ime.internal.MessageExchangeContextListener;
import org.apache.axis.ime.internal.MessageExchangeImpl;
import org.apache.axis.ime.internal.MessageWorkerGroup;

/**
 * This will simply echo messages back
 * 
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class TestProvider {

  public static final MessageChannel SEND = 
    new MessageChannel();
  public static final MessageChannel RECEIVE = 
    new MessageChannel();
  public static MessageWorkerGroup workerpool = 
    new MessageWorkerGroup();
    
  public void init() {
    init(10);
  }

  public void init(int numworkers) {
    for (int n = 0; n < numworkers; n++) {
      workerpool.add(
        SEND, new SendListener());
      workerpool.add(
        RECEIVE, new ReceiveListener());
    }
  }

  public void shutdown() {
    shutdown(false);
  }

  public void shutdown(boolean force) {
    if (force)
      workerpool.interrupt();
    else 
      workerpool.safeInterrupt();
  }

  public MessageExchange createMessageExchange() {
    return new MessageExchangeImpl(
      SEND, RECEIVE);
  }

  public class SendListener
    implements MessageExchangeContextListener {
      
    /**
     * @see org.apache.axis.ime.MessageExchangeContextListener#onMessageExchangeContext(MessageExchangeContext)
     */
    public void onMessageExchangeContext(
      MessageExchangeContext context) {
        try {
          MessageContext msgContext = 
            context.getMessageContext();
          MessageExchangeCorrelator correlator = 
            context.getMessageExchangeCorrelator();

          MessageExchangeStatusListener listener = 
            context.getMessageExchangeStatusListener();
          if (listener != null) {
            listener.onStatus(
              correlator,
              new TestStatusEvent());
          }
       
          Message reqMessage = msgContext.getRequestMessage();
          msgContext.setResponseMessage(reqMessage);
          RECEIVE.put(correlator, context);
        } catch (Exception exception) {
          MessageExchangeFaultListener listener = 
            context.getMessageExchangeFaultListener();
          if (listener != null) 
            listener.onFault(
              context.getMessageExchangeCorrelator(),
              exception);
        }
    }
  }
  
  public class ReceiveListener
    implements MessageExchangeContextListener {
      
    /**
     * @see org.apache.axis.ime.MessageExchangeContextListener#onMessageExchangeContext(MessageExchangeContext)
     */
    public void onMessageExchangeContext(
      MessageExchangeContext context) {
        try {
          MessageExchangeReceiveListener receiveListener = 
            context.getMessageExchangeReceiveListener();
          MessageContext msgContext = context.getMessageContext();
          // there should be code here to see if the message
          // contains a fault.  if so, the fault listener should
          // be invoked
          if (msgContext != null &&
              msgContext.getResponseMessage() != null &&
              receiveListener != null) {
            receiveListener.onReceive(
              context.getMessageExchangeCorrelator(),
              context.getMessageContext()
            );
          }        
        } catch (Exception exception) {
          MessageExchangeFaultListener listener = 
            context.getMessageExchangeFaultListener();
          if (listener != null) 
            listener.onFault(
              context.getMessageExchangeCorrelator(),
              exception);
        }
    }
  }
}
