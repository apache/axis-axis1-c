package org.apache.axis.ime.internal;

import org.apache.axis.ime.*;

/**
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class MessageWorkerGroup {

  protected ThreadGroup group; 
  public boolean interrupt;
  
  public void add(
    MessageChannel channel, 
    MessageExchangeContextListener listener) {
    if (group == null) group = new ThreadGroup(getClass().getName());
    MessageWorker worker = new MessageWorker(this, channel, listener);
    Thread thread = new Thread(group, worker);
    thread.start();
  }

  public synchronized void safeInterrupt() {
    interrupt = true;
  }

  public synchronized boolean interrupted() {
    return interrupt;
  }

  public void interrupt() {
    if (group == null) return;
    group.interrupt(); 
  }

  public void destroy() {
    if (group == null) return;
    group.destroy();
  }

  public void stop() {
    if (group == null) return;
    group.stop();
  }

  public int activeCount() {
    if (group == null) return 0;
    return group.activeCount();
  }  
}

