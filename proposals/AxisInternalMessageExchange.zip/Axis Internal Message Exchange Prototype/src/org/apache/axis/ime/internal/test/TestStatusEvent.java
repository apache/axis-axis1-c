package org.apache.axis.ime.internal.test;

import org.apache.axis.ime.MessageExchangeStatus;

/**
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class TestStatusEvent implements MessageExchangeStatus {}
