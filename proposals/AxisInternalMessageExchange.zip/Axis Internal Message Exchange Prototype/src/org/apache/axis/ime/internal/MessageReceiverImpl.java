package org.apache.axis.ime.internal;

import org.apache.axis.MessageContext;
import org.apache.axis.ime.MessageChannel;
import org.apache.axis.ime.MessageExchangeCorrelator;
import org.apache.axis.ime.MessageExchangeContext;
import org.apache.axis.ime.MessageExchangeContextListener;
import org.apache.axis.ime.MessageExchangeFaultListener;
import org.apache.axis.ime.MessageExchangeReceiveListener;
import org.apache.axis.ime.MessageExchangeStatusListener;
import org.apache.axis.ime.MessageReceiver;

/**
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class MessageReceiverImpl implements MessageReceiver {

  private static final long WORKER_COUNT = 5;

  private MessageExchangeReceiveListener receiveListener;
  private MessageExchangeStatusListener  statusListener;
  private MessageExchangeFaultListener   faultListener;
  private MessageChannel                 channel;
  private MessageWorkerGroup             workers = new MessageWorkerGroup();

  public MessageReceiverImpl(MessageChannel channel) {
    this.channel = channel;
  }

  /**
   * @see org.apache.axis.ime.MessageReceiver#setMessageExchangeReceiveListener(MessageExchangeReceiveListener)
   */
  public void setMessageExchangeReceiveListener(
    MessageExchangeReceiveListener listener) {
      this.receiveListener = listener;
  }

  /**
   * @see org.apache.axis.ime.MessageReceiver#setMessageExchangeStatusListener(MessageExchangeStatusListener)
   */
  public void setMessageExchangeStatusListener(
    MessageExchangeStatusListener listener) {
      this.statusListener = listener;
  }

  /**
   * @see org.apache.axis.ime.MessageReceiver#setMessageExchangeFaultListener(MessageExchangeFaultListener)
   */
  public void setMessageExchangeFaultListener(
    MessageExchangeFaultListener listener) {
      this.faultListener = listener;
  }

  /**
   * @see org.apache.axis.ime.MessageReceiver#listen()
   */
  public void listen() {
    for (int n = 0; n < WORKER_COUNT; n++) {
      workers.addWorker(channel, new Listener());
    }
  }

  /**
   * @see org.apache.axis.ime.MessageReceiver#cancel()
   */
  public void cancel() {
    cancel(false);
  }

  /**
   * @see org.apache.axis.ime.MessageReceiver#cancel(boolean)
   */
  public void cancel(boolean force) {
    if (!force) 
      workers.safeShutdown();
    else 
      workers.shutdown();
  }

  private class Listener 
    implements MessageExchangeContextListener {
      
    /**
     * @see org.apache.axis.ime.MessageExchangeContextListener#onMessageExchangeContext(MessageExchangeContext)
     */
    public void onMessageExchangeContext(
      MessageExchangeContext context) {

        MessageExchangeReceiveListener receiveListener = 
          context.getMessageExchangeReceiveListener();
        MessageExchangeFaultListener faultListener = 
          context.getMessageExchangeFaultListener();
        MessageContext msgContext = 
          context.getMessageContext();
        MessageExchangeCorrelator correlator = 
          context.getMessageExchangeCorrelator();

        try {
          // there should be code here to see if the message
          // contains a fault.  if so, the fault listener should
          // be invoked
          if (msgContext != null &&
              msgContext.getResponseMessage() != null &&
              receiveListener != null) {
            receiveListener.onReceive(correlator, msgContext);
          }        
        } catch (Exception exception) {
          if (faultListener != null) 
            faultListener.onFault(
              correlator, exception);
        }
      
    }
  }
}
