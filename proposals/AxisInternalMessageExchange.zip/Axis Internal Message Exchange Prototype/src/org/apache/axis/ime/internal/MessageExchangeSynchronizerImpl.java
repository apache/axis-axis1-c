package org.apache.axis.ime.internal;

import org.apache.axis.AxisFault;
import org.apache.axis.MessageContext;
import org.apache.axis.ime.MessageExchange;
import org.apache.axis.ime.MessageExchangeCorrelator;
import org.apache.axis.ime.MessageExchangeReceiveListener;
import org.apache.axis.ime.MessageExchangeFaultListener;
import org.apache.axis.ime.MessageExchangeSynchronizer;

/**
 * Used to synchronize send and receives on the MessageExchange
 * 
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class MessageExchangeSynchronizerImpl
  implements MessageExchangeSynchronizer {

  private static final long DEFAULT_TIMEOUT = 1000 * 20;

  protected Holder holder;
  protected MessageExchange exchange;
  
  private MessageExchangeSynchronizerImpl() {}
  
  public MessageExchangeSynchronizerImpl(MessageExchange exchange) {
    this.exchange = exchange;
  }

  public MessageExchange getMessageExchange() {
    return this.exchange;
  }
  
  public MessageContext sendAndReceive(
    MessageContext context)
      throws AxisFault {
    holder = new Holder();
    Listener listener = new Listener(holder);
    exchange.setMessageExchangeFaultListener(listener);
    exchange.setMessageExchangeReceiveListener(listener);
    try {
      exchange.send(context);
      holder.waitForNotify();
    } catch (InterruptedException ie) {
      throw AxisFault.makeFault(ie);
    }
    if (holder.context != null) {
      return holder.context;
    }
    if (holder.exception != null) {
      throw AxisFault.makeFault((Exception)holder.exception);
    }
    return null;
  }
  
  public MessageContext sendAndReceive(
    MessageContext context,
    long timeout)
      throws AxisFault {
    holder = new Holder();
    Listener listener = new Listener(holder);
    exchange.setMessageExchangeFaultListener(listener);
    exchange.setMessageExchangeReceiveListener(listener);
    try {
      exchange.send(context);
      holder.waitForNotify(timeout);
    } catch (InterruptedException ie) {
      throw AxisFault.makeFault(ie);
    }
    if (holder.context != null) {
      return holder.context;
    }
    if (holder.exception != null) {
      throw AxisFault.makeFault((Exception)holder.exception);
    }
    return null;
  }

  private class Holder {
    private MessageExchangeCorrelator correlator;
    private MessageContext context;
    private Throwable exception;
    
    public synchronized void set(
      MessageExchangeCorrelator correlator,
      MessageContext context) {
        this.correlator = correlator;
        this.context = context;
        notifyAll();
    }
    
    public synchronized void set(
      MessageExchangeCorrelator correlator,
      Throwable throwable) {
        this.correlator = correlator;
        this.exception = throwable;
        notifyAll();
    }
    
    public synchronized void waitForNotify()
      throws InterruptedException {
        wait();
        return;
    }
    
    public synchronized void waitForNotify(long timeout)
      throws InterruptedException {
        wait(timeout);
        return;
    }
    
  }

  public class Listener 
    implements MessageExchangeReceiveListener,
                MessageExchangeFaultListener {
                  
    protected Holder holder;
    
    public Listener(Holder holder) {
      this.holder = holder;
    }
                  
    /**
     * @see org.apache.axis.ime.MessageExchangeReceiveListener#onReceive(MessageExchangeCorrelator, MessageContext)
     */
    public void onReceive(
      MessageExchangeCorrelator correlator,
      MessageContext context) {
        holder.set(correlator,context);
    }

    /**
     * @see org.apache.axis.ime.MessageExchangeFaultListener#onFault(MessageExchangeCorrelator, Throwable)
     */
    public void onFault(
      MessageExchangeCorrelator correlator,
      Throwable exception) {
        holder.set(correlator,exception);
    }
    
  }
  
}


