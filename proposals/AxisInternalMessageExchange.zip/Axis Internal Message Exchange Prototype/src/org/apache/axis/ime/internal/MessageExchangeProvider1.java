package org.apache.axis.ime.internal;

import org.apache.axis.ime.MessageExchange;

/**
 * Serves as a base class for MessageExchangeProviders that
 * need to thread pooling on send AND receive message 
 * flows (as opposed to MessageExchangeProvider2 which only
 * does thread pooling on send flows).
 * 
 * @author James M Snell (jasnell@us.ibm.com)
 */
public abstract class MessageExchangeProvider1 {

  public static final long DEFAULT_THREAD_COUNT = 5;

  protected final MessageChannel SEND        = new NonPersistentMessageChannel();
  protected final MessageChannel RECEIVE     = new NonPersistentMessageChannel();
  protected final MessageWorkerGroup WORKERS = new MessageWorkerGroup();
    
  protected abstract MessageExchangeContextListener createSendMessageContextListener();
  
  protected abstract MessageExchangeContextListener createReceiveMessageContextListener();
  
  public MessageExchange createMessageExchange() {
    return new MessageExchangeImpl(SEND,RECEIVE);
  }
  
  public void init() {
    init(DEFAULT_THREAD_COUNT);
  }
  
  public void init(long THREAD_COUNT) {
    for (int n = 0; n < THREAD_COUNT; n++) {
      WORKERS.add(SEND, createSendMessageContextListener());
      WORKERS.add(RECEIVE, createReceiveMessageContextListener());
    }
  }
  
  public void interrupt() {
    interrupt(false);
  }
  
  public void interrupt(boolean force) {
    if (!force) {
      WORKERS.safeInterrupt();
    } else {
      WORKERS.interrupt();
    }
  }
  
}
