package org.apache.axis.ime.internal;

import org.apache.axis.AxisFault;
import org.apache.axis.MessageContext;
import org.apache.axis.ime.MessageExchange;
import org.apache.axis.ime.MessageExchangeCorrelator;
import org.apache.axis.ime.MessageExchangeStatus;
import org.apache.axis.ime.MessageExchangeReceiveListener;
import org.apache.axis.ime.MessageExchangeStatusListener;
import org.apache.axis.ime.MessageExchangeFaultListener;

/**
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class MessageExchangeImpl implements MessageExchange {

  public static final String MESSAGE_CORRELATOR_PROPERTY = 
    MessageExchangeCorrelator.class.getName();

  private MessageChannel send;
  private MessageChannel receive;
  private MessageExchangeReceiveListener receiveListener;
  private MessageExchangeStatusListener statusListener;
  private MessageExchangeFaultListener faultListener;

  private MessageExchangeImpl() {}
  
  public MessageExchangeImpl(
    MessageChannel sendChannel,
    MessageChannel receiveChannel) {
      this.send = sendChannel;
      this.receive = receiveChannel;
  }

  /**
   * @see org.apache.axis.ime.MessageExchange#send(MessageContext)
   */
  public MessageExchangeCorrelator send(
    MessageContext context) 
      throws AxisFault {
    MessageExchangeCorrelator correlator = 
      (MessageExchangeCorrelator)context.getProperty(
        MESSAGE_CORRELATOR_PROPERTY);
    if (correlator == null) { // need to generate an id
      correlator = new MessageExchangeCorrelator("test");
      context.setProperty(
        MESSAGE_CORRELATOR_PROPERTY,
        correlator);
    }
    MessageExchangeContext meContext = 
      new MessageExchangeContext(
        correlator, 
        statusListener,
        receiveListener,
        faultListener,
        context);
    send.put(correlator, meContext);
    return correlator;
  }

  /**
   * @see org.apache.axis.ime.MessageExchange#setMessageExchangeStatusListener(MessageExchangeStatusListener)
   */
  public void setMessageExchangeStatusListener(
    MessageExchangeStatusListener listener)
      throws AxisFault {
      this.statusListener = listener;
  }

  /**
   * @see org.apache.axis.ime.MessageExchange#setMessageExchangeReceiveListener(MessageExchangeReceiveListener)
   */
  public void setMessageExchangeReceiveListener(
    MessageExchangeReceiveListener listener)
      throws AxisFault {
      this.receiveListener = listener;
  }

  /**
   * @see org.apache.axis.ime.MessageExchange#setMessageExchangeReceiveListener(MessageExchangeReceiveListener)
   */
  public void setMessageExchangeFaultListener(
    MessageExchangeFaultListener listener)
      throws AxisFault {
      this.faultListener = listener;
  }

  /**
   * @see org.apache.axis.ime.MessageExchange#cancel(MessageExchangeCorrelator)
   */
  public boolean cancel(MessageExchangeCorrelator correlator)
    throws AxisFault {
    return send.cancel(correlator);
  }

}
