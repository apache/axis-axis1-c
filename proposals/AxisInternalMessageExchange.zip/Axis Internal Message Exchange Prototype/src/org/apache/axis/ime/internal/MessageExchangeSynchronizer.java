package org.apache.axis.ime.internal;

import org.apache.axis.AxisFault;
import org.apache.axis.MessageContext;
import org.apache.axis.ime.MessageExchange;
import org.apache.axis.ime.MessageExchangeCorrelator;
import org.apache.axis.ime.MessageExchangeReceiveListener;
import org.apache.axis.ime.MessageExchangeFaultListener;

/**
 * Used to synchronize send and receives on the MessageExchange
 * 
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class MessageExchangeSynchronizer {

  private static final long DEFAULT_TIMEOUT = 1000 * 20;

  protected MessageExchange exchange;
  
  private MessageExchangeSynchronizer() {}
  
  public MessageExchangeSynchronizer(MessageExchange exchange) {
    this.exchange = exchange;
  }

  public MessageExchange getMessageExchange() {
    return this.exchange;
  }
  
  public MessageContext sendAndReceive(
    MessageContext context)
      throws AxisFault {
    return sendAndReceive(context, DEFAULT_TIMEOUT);
  }
  
  public MessageContext sendAndReceive(
    MessageContext context,
    long timeout)
      throws AxisFault {
    Mutex mutex = new Mutex();
    Holder holder = new Holder();
    Listener listener = new Listener(holder, mutex);
    exchange.setMessageExchangeFaultListener(listener);
    exchange.setMessageExchangeReceiveListener(listener);
    try {
      mutex.acquire();
      exchange.send(context);
      if (mutex.attempt(1000 * 20)) mutex.release();
    } catch (InterruptedException ie) {
      throw AxisFault.makeFault(ie);
    }
    if (holder.context != null) {
      return holder.context;
    }
    if (holder.exception != null) {
      throw AxisFault.makeFault((Exception)holder.exception);
    }
    return null;
  }

  private class Holder {
    public MessageExchangeCorrelator correlator;
    public MessageContext context;
    public Throwable exception;
  }

  private class Listener 
    implements MessageExchangeReceiveListener,
                MessageExchangeFaultListener {
                  
    protected Holder holder;
    protected Mutex mutex;
    
    public Listener(Holder holder, Mutex mutex) {
      this.holder = holder;
      this.mutex = mutex;
    }
                  
    /**
     * @see org.apache.axis.ime.MessageExchangeReceiveListener#onReceive(MessageExchangeCorrelator, MessageContext)
     */
    public void onReceive(
      MessageExchangeCorrelator correlator,
      MessageContext context) {
        synchronized(holder) {
          holder.correlator = correlator;
          holder.context = context;
        }
        mutex.release();
    }

    /**
     * @see org.apache.axis.ime.MessageExchangeFaultListener#onFault(MessageExchangeCorrelator, Throwable)
     */
    public void onFault(
      MessageExchangeCorrelator correlator,
      Throwable exception) {
        synchronized(holder) {
          holder.correlator = correlator;
          holder.exception = exception;
        }
        mutex.release();
    }
    
  }

  private class Mutex {
  
    protected boolean inuse_ = false;
  
    public void acquire() throws InterruptedException {
      if (Thread.interrupted()) throw new InterruptedException();
      synchronized(this) {
        try {
          while (inuse_) wait();
          inuse_ = true;
        }
        catch (InterruptedException ex) {
          notify();
          throw ex;
        }
      }
    }
  
    public synchronized void release()  {
      inuse_ = false;
      notify(); 
    }
  
    public boolean attempt(long msecs) throws InterruptedException {
      if (Thread.interrupted()) throw new InterruptedException();
      synchronized(this) {
        if (!inuse_) {
          inuse_ = true;
          return true;
        }
        else if (msecs <= 0)
          return false;
        else {
          long waitTime = msecs;
          long start = System.currentTimeMillis();
          try {
            for (;;) {
              wait(waitTime);
              if (!inuse_) {
                inuse_ = true;
                return true;
              }
              else {
                waitTime = msecs - (System.currentTimeMillis() - start);
                if (waitTime <= 0) 
                  return false;
              }
            }
          }
          catch (InterruptedException ex) {
            notify();
            throw ex;
          }
        }
      }  
    }
  }
  
}


