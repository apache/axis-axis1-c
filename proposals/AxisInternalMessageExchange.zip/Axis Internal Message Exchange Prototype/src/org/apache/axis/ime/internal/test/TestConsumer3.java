package org.apache.axis.ime.internal.test;

import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.client.AxisClient;
import org.apache.axis.ime.MessageExchange;
import org.apache.axis.ime.MessageExchangeCorrelator;
import org.apache.axis.ime.MessageExchangeReceiveListener;
import org.apache.axis.ime.internal.MessageExchangeSynchronizerImpl;

/**
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class TestConsumer3 {

  public static void main(String[] args) throws Exception {
    TestProvider tester = new TestProvider();
    try {      
     AxisClient engine = new AxisClient();    
     MessageContext context = new MessageContext(engine);
     Message message = new Message("test");
     context.setRequestMessage(message);
    
     tester.init();

     MessageExchange exchange = tester.createMessageExchange();
     MessageExchangeSynchronizerImpl sync = new MessageExchangeSynchronizerImpl(exchange);

     long total = 0;

     sync.sendAndReceive(context, 1000 * 10); // initial op to prime the pump

     for (int n = 0; n < 100; n++) {
       System.out.println("Running test #" + (n + 1));
       long start = System.currentTimeMillis();
       MessageContext result = sync.sendAndReceive(context, 1000 * 10);
       total += System.currentTimeMillis() - start;
       System.out.println(" ====> " + total / (n + 1));
       if (result == null) System.out.println("!!!FAILED!!!");
     }
    
     System.out.println(total/100);
    } catch (Exception e) {
      throw e;
    } finally {
     tester.shutdown();
    }
  }

}
