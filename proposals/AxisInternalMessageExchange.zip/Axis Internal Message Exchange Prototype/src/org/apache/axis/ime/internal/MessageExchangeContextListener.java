package org.apache.axis.ime.internal;

/**
 * @author James M Snell (jasnell@us.ibm.com)
 */
public interface MessageExchangeContextListener {

  public void onMessageExchangeContext(
    MessageExchangeContext context);

}
