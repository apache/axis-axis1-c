package org.apache.axis.ime.internal;

import org.apache.axis.MessageContext;
import org.apache.axis.ime.*;

/**
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class MessageWorker implements Runnable {

  protected MessageWorkerGroup pool;
  protected MessageChannel channel;
  protected MessageExchangeContextListener listener;
  
  private MessageWorker() {}

  public MessageWorker(
    MessageWorkerGroup pool,
    MessageChannel channel) {
    this.pool = pool;
    this.channel = channel;
  }
  
  public MessageWorker(
    MessageWorkerGroup pool,
    MessageChannel channel,
    MessageExchangeContextListener listener) {
    this(pool,channel);
    this.listener = listener;
  }

  /**
   * @see java.lang.Runnable#run()
   */
  public void run() {
    while (!pool.interrupted()) {
      try {
        listener.onMessageExchangeContext(channel.select());
      } catch (InterruptedException ie) {
        return;
      } catch (Throwable t) {
        // do something, but don't die or we'll lose the thread
        // should at least log the event
      }
    }
  }

}
