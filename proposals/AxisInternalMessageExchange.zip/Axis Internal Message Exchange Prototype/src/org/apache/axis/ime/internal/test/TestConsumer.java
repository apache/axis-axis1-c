package org.apache.axis.ime.internal.test;

import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.client.AxisClient;
import org.apache.axis.ime.MessageExchange;
import org.apache.axis.ime.MessageExchangeCorrelator;
import org.apache.axis.ime.MessageExchangeReceiveListener;

/**
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class TestConsumer {

  private static final int testcount = 100;
  protected static Counter counter = new Counter(testcount);

  public static void main(String[] args) throws Exception {

    AxisClient engine = new AxisClient();    
    MessageContext context = new MessageContext(engine);
    Message message = new Message("test");
    context.setRequestMessage(message);
    
    TestProvider tester = new TestProvider();
    tester.init();
    
    MessageExchange exchange = tester.createMessageExchange();
    
    MessageExchangeReceiveListener receiveListener = 
      new MessageExchangeReceiveListener() {
        /**
         * @see org.apache.axis.ime.MessageExchangeReceiveListener#onReceive(MessageExchangeCorrelator, MessageContext)
         */
        public void onReceive(
          MessageExchangeCorrelator correlator,
          MessageContext context) {
            System.out.println(Thread.currentThread());
            counter.increment();
          }

      };
    
    exchange.setMessageExchangeReceiveListener(receiveListener);
    for (int n = 0; n < testcount; n++) {
      exchange.send(context);
    }

    counter.waitForTarget();
    tester.shutdown();
  }

  private static class Counter {
    private int target;
    private int current;
    
    public Counter(int target) {
      this.target = target;
    }
    
    public synchronized void increment() {
      current++;
      if (current == target) notifyAll();
    }
    
    public synchronized void waitForTarget() {
      try {
        wait();
      } catch (Exception e) {}
    }
  }
}
