package org.apache.axis.ime.internal.test;

import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.client.AxisClient;
import org.apache.axis.ime.MessageExchange;
import org.apache.axis.ime.MessageExchangeCorrelator;
import org.apache.axis.ime.MessageExchangeReceiveListener;
import org.apache.axis.ime.internal.MessageExchangeSynchronizerImpl;

/**
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class TestConsumer2 {

  public static void main(String[] args) throws Exception {
    
    AxisClient engine = new AxisClient();    
    MessageContext context = new MessageContext(engine);
    Message message = new Message("test");
    context.setRequestMessage(message);
    
    TestProvider tester = new TestProvider();
    tester.init();

    MessageExchange exchange = tester.createMessageExchange();
    MessageExchangeSynchronizerImpl sync = new MessageExchangeSynchronizerImpl(exchange);
    sync.sendAndReceive(context, 1000 * 10);
    System.out.println(context.getResponseMessage());
    
    tester.shutdown();
  }

}
