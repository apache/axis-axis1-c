package org.apache.axis.ime.internal;

/**
 * Different implementations may allow for variations on 
 * how the MessageChannel model is implemented.  For instance,
 * the code will ship with a NonPersistentMessageChannel that
 * will store all MessageContext objects in memory.  The 
 * fact that everything is stored in memory means that the
 * Channel is not fault tolerant.  If fault tolerance is 
 * required, then a PersistentMessageChannel must be created
 * that stores the MessageContext objects somehow.
 * 
 * @author James M Snell (jasnell@us.ibm.com)
 */
public interface MessageChannel {

  public MessageExchangeContext peek();
  
  public void put(
    Object key, 
    MessageExchangeContext context);
    
  public boolean cancel(
    Object key);
  
  public MessageExchangeContext select()
    throws InterruptedException;

  public MessageExchangeContext select(long timeout)
    throws InterruptedException;
    
  public MessageExchangeContext select(Object key)
    throws InterruptedException;
    
}
