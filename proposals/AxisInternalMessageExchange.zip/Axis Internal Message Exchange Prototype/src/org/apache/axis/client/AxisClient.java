package org.apache.axis.client;

import org.apache.axis.AxisEngine;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.Handler;
import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.handlers.soap.SOAPService;
import org.apache.axis.ime.MessageExchange;
import org.apache.axis.ime.MessageExchangeContext;
import org.apache.axis.ime.MessageExchangeContextListener;
import org.apache.axis.ime.MessageExchangeCorrelator;
import org.apache.axis.ime.MessageExchangeFaultListener;
import org.apache.axis.ime.MessageExchangeReceiveListener;
import org.apache.axis.ime.MessageExchangeStatus;
import org.apache.axis.ime.MessageExchangeStatusListener;
import org.apache.axis.ime.MessageExchangeSynchronizer;
import org.apache.axis.ime.MessageReceiver;

/**
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class AxisClient extends AxisEngine {

  public AxisClient() {
    super(null);  // for testing
  }

  /**
   * Constructor for AxisClient.
   * @param config
   */
  public AxisClient(EngineConfiguration config) {
    super(config);
  }

  /**
   * @see org.apache.axis.AxisEngine#initMessageExchangeProvider()
   */
  public void initMessageExchangeProvider() {
    long threadcount = ((Long)getOption(PROP_WORKERTHREAD_COUNT)).longValue();
    initMessageExchangeProvider(threadcount);
  }

  /**
   * @see org.apache.axis.AxisEngine#initMessageExchangeProvider()
   */
  public void initMessageExchangeProvider(long threadcount) {
    for (int n = 0; n < threadcount; n++) {
      workerGroup.addWorker(send, createSendMessageContextListener());
      workerGroup.addWorker(receive, createReceiveMessageContextListener());
    }
  }

  /**
   * @see org.apache.axis.AxisEngine#getClientEngine()
   */
  public AxisEngine getClientEngine() {
    return this;
  }

  /**
   * @see org.apache.axis.ime.MessageReceiverFactory#createMessageReceiver()
   */
  public MessageReceiver createMessageReceiver() {
    throw new UnsupportedOperationException();
  }

  /**
   * @see org.apache.axis.ime.internal.MessageExchangeProvider1#createReceiveMessageContextListener()
   */
  protected MessageExchangeContextListener createReceiveMessageContextListener() {
    return new ContextReceiveListener();
  }

  /**
   * @see org.apache.axis.ime.internal.MessageExchangeProvider1#createSendMessageContextListener()
   */
  protected MessageExchangeContextListener createSendMessageContextListener() {
    return new ContextSendListener();
  }


  public class ContextSendListener
    implements MessageExchangeContextListener {
      
    /**
     * @see org.apache.axis.ime.MessageExchangeContextListener#onMessageExchangeContext(MessageExchangeContext)
     */
    public void onMessageExchangeContext(
      MessageExchangeContext context) {
        try {
          MessageContext msgContext = 
            context.getMessageContext();
          MessageExchangeCorrelator correlator = 
            context.getMessageExchangeCorrelator();

          String hName = null;
          Handler h = null;
          MessageContext previousContext = getCurrentMessageContext();
          
            setCurrentMessageContext(msgContext);
            // gonna ignore the ENGINE_HANDLER function for now
            SOAPService service = null;
            msgContext.setPastPivot(false);
            service = msgContext.getService();
            if ( service != null ) {
              h = service.getRequestHandler();
              if ( h != null )
                h.invoke( msgContext );
            }
            
            if ((h = getGlobalRequest()) != null )
              h.invoke(msgContext);
  
            //invokeJAXRPCHandlers(msgContext);
            
            correlatorService.put(correlator, context);
            
            MessageExchange transport = 
              getTransport(msgContext.getTransportName());
            if (transport != null) {
              MessageExchangeReceiveListener receiveListener = new ReceiveListener();
              MessageExchangeFaultListener   faultListener   = new FaultListener();
              MessageExchangeStatusListener  statusListener  = new StatusListener();
              transport.setMessageExchangeFaultListener(faultListener);
              transport.setMessageExchangeReceiveListener(receiveListener);
              transport.setMessageExchangeStatusListener(statusListener);
              transport.send(msgContext);
            }
              
          setCurrentMessageContext(previousContext);    

        } catch (Exception exception) {
          MessageExchangeFaultListener listener = 
            context.getMessageExchangeFaultListener();
          if (listener != null) 
            listener.onFault(
              context.getMessageExchangeCorrelator(),
              exception);
        }
    }
  }

  public class ContextReceiveListener
    implements MessageExchangeContextListener {
      
    /**
     * @see org.apache.axis.ime.MessageExchangeContextListener#onMessageExchangeContext(MessageExchangeContext)
     */
    public void onMessageExchangeContext(
      MessageExchangeContext context) {

        MessageExchangeReceiveListener receiveListener = 
          context.getMessageExchangeReceiveListener();
        MessageExchangeFaultListener faultListener = 
          context.getMessageExchangeFaultListener();
        MessageContext msgContext = 
          context.getMessageContext();
        MessageExchangeCorrelator correlator = 
          context.getMessageExchangeCorrelator();

        MessageContext previousContext = getCurrentMessageContext();

        try {

          Handler h = null;  
                  
          //invokeJAXRPCHandlers(msgContext);

          /* Process the Global Response Chain */
          /***********************************/
          if ((h = getGlobalResponse()) != null) {
            h.invoke(msgContext);
          }

          SOAPService service = msgContext.getService();
          if ( service != null ) {
            h = service.getResponseHandler();
            if ( h != null ) {
              h.invoke(msgContext);
            }
          }          
          
          // there should be code here to see if the message
          // contains a fault.  if so, the fault listener should
          // be invoked
          
          if (msgContext != null &&
              msgContext.getResponseMessage() != null &&
              receiveListener != null) {
            receiveListener.onReceive(correlator, msgContext);
          }        
        } catch (Exception exception) {
          if (faultListener != null) 
            faultListener.onFault(
              correlator, exception);
        }
        
        setCurrentMessageContext(previousContext);      
    }
  }

  public class ReceiveListener
    implements MessageExchangeReceiveListener {
    /**
     * @see org.apache.axis.ime.MessageExchangeReceiveListener#onReceive(MessageExchangeCorrelator, MessageContext)
     */
    public void onReceive(
      MessageExchangeCorrelator correlator,
      MessageContext context) {
        MessageExchangeContext origContext = 
          correlatorService.get(correlator);
        RECEIVE.put(correlator, origContext);
      }
  }

  public class StatusListener
    implements MessageExchangeStatusListener {
    /**
     * @see org.apache.axis.ime.MessageExchangeStatusListener#onStatus(MessageExchangeCorrelator, MessageExchangeStatus)
     */
    public void onStatus(
      MessageExchangeCorrelator correlator,
      MessageExchangeStatus status) {
        MessageExchangeContext origContext =
          correlatorService.get(correlator);
        MessageExchangeStatusListener listener =
          origContext.getMessageExchangeStatusListener();
        listener.onStatus(correlator, status);
      }
  }
  
  public class FaultListener
    implements MessageExchangeFaultListener {
      /**
     * @see org.apache.axis.ime.MessageExchangeStatusListener#onStatus(MessageExchangeCorrelator, MessageExchangeStatus)
     */
    public void onFault(
      MessageExchangeCorrelator correlator,
      Throwable exception) {
        MessageExchangeContext origContext =
          correlatorService.get(correlator);
        MessageExchangeFaultListener listener =
          origContext.getMessageExchangeFaultListener();
        listener.onFault(correlator, exception);        
      }
  }
  
}
