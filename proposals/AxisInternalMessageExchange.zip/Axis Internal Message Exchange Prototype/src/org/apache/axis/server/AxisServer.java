package org.apache.axis.server;

import org.apache.axis.AxisEngine;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.ime.MessageExchange;
import org.apache.axis.ime.MessageExchangeContext;
import org.apache.axis.ime.MessageExchangeContextListener;
import org.apache.axis.ime.MessageExchangeCorrelator;
import org.apache.axis.ime.MessageExchangeFaultListener;
import org.apache.axis.ime.MessageExchangeReceiveListener;
import org.apache.axis.ime.MessageExchangeStatusListener;
import org.apache.axis.ime.MessageExchangeSynchronizer;
import org.apache.axis.ime.MessageReceiver;

/**
 * @author James M Snell (jasnell@us.ibm.com)
 */
public class AxisServer extends AxisEngine {

  public AxisServer() {
    super(null);  // for now
  }

  /**
   * Constructor for AxisClient.
   * @param config
   */
  public AxisServer(EngineConfiguration config) {
    super(config);
  }

  /**
   * @see org.apache.axis.AxisEngine#initMessageExchangeProvider()
   */
  public void initMessageExchangeProvider() {
    long threadcount = ((Long)getOption(PROP_WORKERTHREAD_COUNT)).longValue();
    initMessageExchangeProvider(threadcount);
  }

  /**
   * @see org.apache.axis.AxisEngine#initMessageExchangeProvider()
   */
  public void initMessageExchangeProvider(long threadcount) {
    for (int n = 0; n < threadcount; n++) {
      workerGroup.addWorker(send, createSendMessageContextListener());
      workerGroup.addWorker(receive, createReceiveMessageContextListener());
    }
  }

  /**
   * @see org.apache.axis.AxisEngine#getClientEngine()
   */
  public AxisEngine getClientEngine() {
    return this;
  }

  /**
   * @see org.apache.axis.ime.MessageReceiverFactory#createMessageReceiver()
   */
  public MessageReceiver createMessageReceiver() {
    throw new UnsupportedOperationException();
  }

  /**
   * @see org.apache.axis.ime.internal.MessageExchangeProvider1#createReceiveMessageContextListener()
   */
  protected MessageExchangeContextListener createReceiveMessageContextListener() {
    return new ReceiveListener();
  }

  /**
   * @see org.apache.axis.ime.internal.MessageExchangeProvider1#createSendMessageContextListener()
   */
  protected MessageExchangeContextListener createSendMessageContextListener() {
    return new SendListener();
  }


  public class SendListener
    implements MessageExchangeContextListener {
      
    /**
     * @see org.apache.axis.ime.MessageExchangeContextListener#onMessageExchangeContext(MessageExchangeContext)
     */
    public void onMessageExchangeContext(
      MessageExchangeContext context) {
        try {
          MessageContext msgContext = 
            context.getMessageContext();
          MessageExchangeCorrelator correlator = 
            context.getMessageExchangeCorrelator();

// gotta do real processing here
          Message reqMessage = msgContext.getRequestMessage();          
          msgContext.setResponseMessage(reqMessage);
// gotta do real processing here          
          
          RECEIVE.put(correlator, context);
        } catch (Exception exception) {
          MessageExchangeFaultListener listener = 
            context.getMessageExchangeFaultListener();
          if (listener != null) 
            listener.onFault(
              context.getMessageExchangeCorrelator(),
              exception);
        }
    }
  }

  public class ReceiveListener
    implements MessageExchangeContextListener {
      
    /**
     * @see org.apache.axis.ime.MessageExchangeContextListener#onMessageExchangeContext(MessageExchangeContext)
     */
    public void onMessageExchangeContext(
      MessageExchangeContext context) {

        MessageExchangeReceiveListener receiveListener = 
          context.getMessageExchangeReceiveListener();
        MessageExchangeFaultListener faultListener = 
          context.getMessageExchangeFaultListener();
        MessageContext msgContext = 
          context.getMessageContext();
        MessageExchangeCorrelator correlator = 
          context.getMessageExchangeCorrelator();

        try {
          // there should be code here to see if the message
          // contains a fault.  if so, the fault listener should
          // be invoked
          if (msgContext != null &&
              msgContext.getResponseMessage() != null &&
              receiveListener != null) {
            receiveListener.onReceive(correlator, msgContext);
          }        
        } catch (Exception exception) {
          if (faultListener != null) 
            faultListener.onFault(
              correlator, exception);
        }
    }
  }

}
