/*
 * The Apache Software License, Version 1.1
 *
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Axis" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

package samples.async;

import java.net.*;

import javax.jms.*;
import javax.xml.namespace.*;
import javax.xml.rpc.*;

import org.apache.axis.async.*;
import org.apache.axis.encoding.*;

/**
 * These examples use the listener receive style of JMS to
 * perform asynchronous RPC.  The main difference between the different receive
 * styles is that a multiple sessions must be used for inbound and outbound.  This
 * is because the client code controls does not control all threads
 * accessing the session.  The benefit of this approach is the code does
 * not have to explicitly poll for received messages.
 *
 * @author Jaime Meritt <jmeritt@sonicsoftware.com>
 */

public class RPCListenerExamples
{


    public static void getQuoteNoWSDL(String sendURL, String receiveURL,
                                      String tickerSymbol) throws Exception
    {

        AxisConnection conn = (AxisConnection) new AxisConnectionFactory().createConnection();

        //need to create 2 session because I am using asynchronous listening model
        //separate sessions are required to prevent concurrent access to the underlying
        //session.
        AxisSession sendSession = (AxisSession) conn.createSession(false, Session.DUPS_OK_ACKNOWLEDGE);
        AxisSession receiveSession = (AxisSession) conn.createSession(false, Session.DUPS_OK_ACKNOWLEDGE);
        AsyncUtils.configureSessions(new AxisSession[]{sendSession, receiveSession});

        Destination sendAddress = sendSession.createDestination(new URL(sendURL));
        MessageProducer producer = sendSession.createProducer(sendAddress);

        Destination replyTo = receiveSession.createDestination(new URL(receiveURL));
        MessageConsumer consumer = receiveSession.createConsumer(replyTo);
        consumer.setMessageListener(new RPCExampleListener(receiveSession));
        conn.start();

        AxisMessage message = sendSession.createAxisMessage(tickerSymbol);
        message.setJMSReplyTo(replyTo);
        producer.send(message);
        AsyncUtils.doSomeWork();
        conn.close();
    }

    /**
     * Everything is set by the WSDL in this scenario so no extra information is
     * required except the params
     * @param tickerSymbol
     * @throws Exception
     */
    public static void getQuoteUsingWSDL(String tickerSymbol) throws Exception
    {
        AxisConnectionFactory factory = new AxisConnectionFactory();
        AxisConnection conn = factory.createConnection(new URL(AsyncUtils.GET_QUOTE_WSDL),
                                                       AsyncUtils.SERVICE_QN);

        //need to create 2 session because I am using asynchronous listening model
        //separate sessions are required to prevent concurrent access to the underlying
        //session.
        AxisSession sendSession = conn.createSession(false,
                                                     Session.DUPS_OK_ACKNOWLEDGE,
                                                     AsyncUtils.PORT_QN, AsyncUtils.GET_QUOTE_OPNAME);
        AxisSession receiveSession = conn.createSession(false,
                                                        Session.DUPS_OK_ACKNOWLEDGE,
                                                        AsyncUtils.PORT_QN, AsyncUtils.GET_QUOTE_OPNAME);

        MessageProducer producer = sendSession.createProducer();
        MessageConsumer consumer = receiveSession.createConsumer();
        consumer.setMessageListener(new RPCExampleListener(receiveSession));
        conn.start();

        AxisMessage message = sendSession.createAxisMessage(tickerSymbol);
        //Notice I don't explicitly set replyTo.  This is prefilled from the WSDL
        producer.send(message);
        AsyncUtils.doSomeWork();
        conn.close();
    }

    public static void main(String[] args) throws Exception
    {
        String sendURL = args[0];
        String receiveURL = args[1];
        String symbol = args[2];
        getQuoteUsingWSDL(symbol);
        getQuoteNoWSDL(sendURL, receiveURL, symbol);
    }

}