/*
 * The Apache Software License, Version 1.1
 *
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Axis" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

package org.apache.axis.async;

import org.apache.axis.AxisFault;
import org.apache.axis.client.Transport;
import org.apache.axis.encoding.DeserializerFactory;
import org.apache.axis.encoding.SerializerFactory;

import javax.jms.*;
import javax.xml.namespace.QName;
import javax.xml.rpc.ParameterMode;
import javax.xml.soap.MimeHeaders;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;
import java.io.InputStream;

/**
 *
 * @author Jaime Meritt <jmeritt@sonicsoftware.com>
 * @author James M Snell <jasnell@us.ibm.com>
 */
public interface AxisSession extends Session
{
    /**
     * creates a destination from a URL
     * @param url the URL for the endpoint
     * @return a configured destination
     * @throws JMSException
     */
    AxisDestination createDestination(URL url) throws JMSException;

    /**
     * creates a destination from a URL
     * @param transport a configured transport Object referencing an endpoint
     * @return a configured destination
     * @throws JMSException
     */
    AxisDestination createDestination(Transport transport) throws JMSException;

    /**
     * creates a destination from a String representation of a URL
     * @param url the URL for the endpoint
     * @return a configured destination
     * @throws JMSException
     */
    AxisDestination createDestination(String url) throws JMSException;

    /**
     * creates a producer appropriate for the send destination in the WSDL.
     * This is not the same as an unbound producer.  This producer is
     * bound to the default destination in the WSDL.  To create an unbound
     * producer pass in null as the destination value
     * @return a producer bound to the send destination specified in the WSDL
     * @throws JMSException if the send destination is indeterminate
     */
    MessageProducer createProducer() throws JMSException;

    /**
     * creates a consumer appropriate for the receive destination in the WSDL.
     * @return a consumer bound to the receive destination specified in the WSDL
     * @throws JMSException if the send destination is indeterminate
     */
    MessageConsumer createConsumer() throws JMSException;

    /**
     * creates a new output message
     * @return the message
     */
    AxisMessage createAxisMessage() throws JMSException;

    /**
     * creates a new axis message
     * @param values
     * @return AxisMessage
     * @throws JMSException
     */
    AxisMessage createAxisMessage(Map values) throws JMSException;

    /**
     * creates a new axis message containing a single value
     * @param value
     * @return AxisMessage
     * @throws JMSException
     */
    AxisMessage createAxisMessage(Object value) throws JMSException;

    /**
     * creates a new axis message containing a single value
     * @param key
     * @param value
     * @return AxisMessage
     * @throws JMSException
     */
    AxisMessage createAxisMessage(Object key, Object value) throws JMSException;

    /**
     * creates a new axis message containing a fault
     * @return the message

     * @param fault the fault to wrap as a SOAP fault
     */
    AxisMessage createAxisMessage(AxisFault fault) throws JMSException;

    /**
     * creates an SAAJMessage.  Clients should use this if they intend to
     * deal with the message through SAAJ APIs
     * @return a new SAAJMessage
     * @throws JMSException
     */
    SAAJMessage createSAAJMessage() throws JMSException;

    /**
     * creates an SAAJMessage.  Clients should use this if they intend to
     * deal with the message through SAAJ APIs
     * @param headers the headers for this message
     * @param in the content to initialize this message with
     * @return a new SAAJMessage
     * @throws JMSException
     */
    SAAJMessage createSAAJMessage(MimeHeaders headers, InputStream in) throws JMSException;

    /**
     * Sets the value for a named property. JAX-RPC specification
     * specifies a standard set of properties that may be passed
     * to the <code>setProperty</code> method.
     *
     * @param name Name of the property
     * @param value Value of the property
     */
    void setProperty(String name, Object value) throws JMSException;

    /**
     * Gets the value of a named property.
     *
     * @param name Name of the property
     *
     * @return Value of the named property
     */
    Object getProperty(String name) throws JMSException;

    /**
     * Removes a named property.
     *
     * @param name Name of the property
     */
    public void removeProperty(String name) throws JMSException;

    /**
     * Gets the names of configurable properties supported by
     * this object.
     *
     * @return Iterator for the property names
     */
    Iterator getPropertyNames() throws JMSException;

    /**
     * Adds a parameter type and mode for a specific  operation.
     * This method is used to specify the Java type for either
     * OUT or INOUT parameters.
     *
     * @param paramName Name of the parameter
     * @param xmlType XML datatype of the parameter
     * @param javaType The Java class of the parameter
     * @param parameterMode Mode of the parameter-whether
     *                ParameterMode.IN, OUT or INOUT
     */
    void addParameter(String paramName, QName xmlType,
                      Class javaType, ParameterMode parameterMode) throws JMSException;

    /**
     * Adds a parameter type and mode for a specific  operation.
     * Note that the client code may not call any
     * <code>addParameter</code> and <code>setReturnType</code>
     * methods before calling the <code>invoke</code> method. In
     * this case, the Call implementation class determines the
     * parameter types by using reflection on parameters, using
     * the WSDL description and configured type mapping registry.
     *
     * @param paramName Name of the parameter
     * @param xmlType XML datatype of the parameter
     * @param parameterMode Mode of the parameter-whether
     *                <code>ParameterMode.IN</code>,
     *                <code>ParameterMode.OUT</code>,
     *                or <code>ParameterMode.INOUT
     * @throws java.lang.IllegalArgumentException If any illegal
     *     parameter name or XML type is specified
     */
    void addParameter(String paramName, QName xmlType,
                      ParameterMode parameterMode) throws JMSException;

    /**
     * Gets the name of the operation to be invoked using this Call instance.
     *
     * @return Qualified name of the operation
     */
    QName getOperationName() throws JMSException;

    /**
     * Sets the name of the operation to be invoked using this
     * <code>Call</code> instance.
     *
     * @param operationName QName of the operation to be
     *                   invoked using the Call instance
     */
    void setOperationName(QName operationName) throws JMSException;

    /**
     * Gets the XML type of a parameter by name
     *
     * @param paramName Name of the parameter.
     *
     * @return Returns XML type for the specified parameter
     */
    QName getParameterTypeByName(String paramName) throws JMSException;

    /**
     * Removes all specified parameters from this <code>Call</code> instance.
     * Note that this method removes only the parameters and not
     * the return type. The <code>setReturnType(null)</code> is
     * used to remove the return type.
     *
     */
    void removeAllParameters() throws JMSException;

    /**
     * Should soapAction be used?
     * @param useSoapAction true if the soap action should be sent over the wire.
     * The mechanism used to send the soap action is transport specific
     */
    void setUseSOAPAction(boolean useSoapAction) throws JMSException;

    /**
     * Set the soapAction URI.
     * @param actionURI the URI to send as the soap action.  It will only
     * be sent if the useSoapAction is set to true
     */
    void setSOAPActionURI(String actionURI) throws JMSException;

    /**
     * Sets the encoding style to the URL passed in.
     *
     * @param namespaceURI URI of the encoding to use.
     */
    void setEncodingStyle(String namespaceURI) throws JMSException;

    /**
     * Returns the encoding style as a URI that should be used for the SOAP
     * message.
     *
     * @return String URI of the encoding style to use
     */
    String getEncodingStyle() throws JMSException;

    /**
     * Gets the return type for a specific operation
     *
     * @return  Returns the XML type for the return value
     */
    QName getReturnType() throws JMSException;

    /**
     * Sets the return type for a specific operation. Invoking
     * <code>setReturnType(null)</code> removes the return
     * type for this Call object.
     *
     * @param xmlType XML data type of the return value
     */
    void setReturnType(QName xmlType) throws JMSException;

    /**
     * Sets the return type for a specific operation.
     *
     * @param xmlType XML data type of the return value
     * @param javaType Java class of the return value
     */
    void setReturnType(QName xmlType, Class javaType) throws JMSException;

    /**
     * Set the operation style: "document", "rpc"
     * @param style string designating style
     */
    void setOperationStyle(String style) throws JMSException;

    /**
     * Set the operation use: "literal", "encoded"
     * @param use string designating use
     */
    void setOperationUse(String use) throws JMSException;

    /**
     * Register type mapping information for serialization/deserialization
     *
     * Note: Not part of JAX-RPC specification.
     *
     * @param javaType is  the Java class of the data type.
     * @param xmlType the xsi:type QName of the associated XML type.
     * @param sf are the factories (or the Class objects of the factory).
     * @param df are the factories (or the Class objects of the factory).
     */
    void registerTypeMapping(Class javaType, QName xmlType,
                             Class sf, Class df) throws JMSException;

    /**
     * Register type mapping information for serialization/deserialization
     *
     * Note: Not part of JAX-RPC specification.
     *
     * @param javaType is  the Java class of the data type.
     * @param xmlType the xsi:type QName of the associated XML type.
     * @param sf are the factories (or the Class objects of the factory).
     * @param df are the factories (or the Class objects of the factory).
     * @param force Indicates whether to add the information if already registered.
     */
    void registerTypeMapping(Class javaType, QName xmlType,
                             Class sf, Class df,
                             boolean force) throws JMSException;

    /**
     * Register type mapping information for serialization/deserialization
     *
     * Note: Not part of JAX-RPC specification.
     *
     * @param javaType is  the Java class of the data type.
     * @param xmlType the xsi:type QName of the associated XML type.
     * @param sf are the factories (or the Class objects of the factory).
     * @param df are the factories (or the Class objects of the factory).
     */
    void registerTypeMapping(Class javaType, QName xmlType,
                             SerializerFactory sf, DeserializerFactory df) throws JMSException;

    /**
     * Register type mapping information for serialization/deserialization
     *
     * Note: Not part of JAX-RPC specification.
     *
     * @param javaType is  the Java class of the data type.
     * @param xmlType the xsi:type QName of the associated XML type.
     * @param sf are the factories (or the Class objects of the factory).
     * @param df are the factories (or the Class objects of the factory).
     * @param force Indicates whether to add the information if already registered.
     */
    void registerTypeMapping(Class javaType, QName xmlType,
                             SerializerFactory sf, DeserializerFactory df,
                             boolean force) throws JMSException;

}