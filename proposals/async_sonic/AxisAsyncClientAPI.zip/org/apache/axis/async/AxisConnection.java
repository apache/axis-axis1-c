/*
 * The Apache Software License, Version 1.1
 *
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Axis" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

package org.apache.axis.async;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.xml.namespace.QName;
import java.util.Iterator;

/**
 * The AxisConnection represents a live connection to a web service.  If the underlying
 * trasnport supports connection creation and maintenance then all method calls that
 * modify the lifecycle of the connection will be delegated sown to the underlying
 * transport connection.
 *
 * An AxisConnection can be associated with a service and a WSDL document.  These
 * values can be set at creation time.  It provides access to a list of ports and
 * the qname it is associated with through various accessor methods.
 *
 * Finally, the main purpose of AxisConnection is to act as a factory for AxisSession
 * instances.
 *
 * @author Jaime Meritt <jmeritt@sonicsoftware.com>
 */
public interface AxisConnection extends Connection
{
    /**
     * gets the QNames of the ports defined in the WSDL document
     * @return zero or more QNames associated with the connection.
     * If the connection is not associated with a WSDL document and
     * a particular service, this method will always return an empty
     * iterator.
     */
    Iterator getPorts() throws JMSException;

    /**
     * gets the QNames of the service associated with this connection
     * @return the QName of the associated service or null if it is unassociated
     */
    QName getServiceName() throws JMSException;

    /**
     * creates an AxisSession associated with a particular port
     * @param transacted true if the session is transacted.  Only applicable to
     * transports that support transactional semantics
     * @param ackMode one of the acknowledgement modes defined in javax.jms.Session
     * @param portName the port name defined in the WSDL document to associate with
     *        this session.  An exception will be thrown if not associated with a WSDL
     *        document
     * @return a AxisSession for interaction with the web service
     */
    AxisSession createSession(boolean transacted, int ackMode,
                              QName portName) throws JMSException;

    /**
     * creates an AxisSession associated with a particular port and operation
     * @param transacted true if the session is transacted.  Only applicable to
     * transports that support transactional semantics
     * @param ackMode one of the acknowledgement modes defined in javax.jms.Session
     * @param portName the port name defined in the WSDL document to associate with
     *        this session.  An exception will be thrown if not associated with a WSDL
     *        document
     * @param operationName the operation name appropriate to the port defined.  An exception
     * will be thrown if the port does not contain the operation
     * @return a AxisSession for interaction with the web service
     */
    AxisSession createSession(boolean transacted, int ackMode,
                              QName portName, QName operationName) throws JMSException;

    /**
     * creates an AxisSession associated with a particular port and operation
     * @param transacted true if the session is transacted.  Only applicable to
     * transports that support transactional semantics
     * @param ackMode one of the acknowledgement modes defined in javax.jms.Session
     * @param portName the port name defined in the WSDL document to associate with
     *        this session.  An exception will be thrown if not associated with a WSDL
     *        document
     * @param operationName the operation name appropriate to the port defined.  An exception
     * will be thrown if the port does not contain the operation
     s* @return a AxisSession for interaction with the web service
     */
    AxisSession createSession(boolean transacted, int ackMode,
                              QName portName, String operationName) throws JMSException;
}